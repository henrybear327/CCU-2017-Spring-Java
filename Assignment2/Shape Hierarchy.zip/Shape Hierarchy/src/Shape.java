abstract public class Shape {
    @Override
    public abstract String toString();
}
